package lambda;

public interface StringJoinnerFunctionalInterface {
	public String StringJoinner(String str,String ptr);
}
