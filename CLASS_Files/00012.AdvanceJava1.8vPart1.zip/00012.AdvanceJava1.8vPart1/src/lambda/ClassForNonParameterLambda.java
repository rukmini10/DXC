package lambda;
@FunctionalInterface
interface DisplayFunctionalInterface{
	void sayGreetings();
}

@FunctionalInterface
interface DisplayFunctionalInterface2{
	String sayGreetings();
}

public class ClassForNonParameterLambda {

	public static void main(String[] args) {
		DisplayFunctionalInterface greetings=() -> {
			System.out.println("Hi all, how are you");
		};
		
		DisplayFunctionalInterface2 greet=() -> {
			 return ("Hi , how are you today");
		};
		greetings.sayGreetings();
		System.out.print("\n"+greet.sayGreetings());
	}

}
