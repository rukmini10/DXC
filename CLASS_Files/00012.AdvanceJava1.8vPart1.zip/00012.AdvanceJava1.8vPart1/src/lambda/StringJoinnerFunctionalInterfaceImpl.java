package lambda;

public class StringJoinnerFunctionalInterfaceImpl {

	public static void main(String[] args) {
		StringJoinnerFunctionalInterface ref=(String str,String ptr) -> str+" "+ptr; 
		System.out.print("\n "+ref.StringJoinner("Kakumani", "Pavan"));
		
	}

}
