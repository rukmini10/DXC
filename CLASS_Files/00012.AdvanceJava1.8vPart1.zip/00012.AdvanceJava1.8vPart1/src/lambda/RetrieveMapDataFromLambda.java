package lambda;

import java.util.HashMap;
import java.util.Map;

public class RetrieveMapDataFromLambda {

	public static void main(String[] args) {
		Map<String,Double> fruits=new HashMap<>();
		fruits.put("Apple", 234.50);
		fruits.put("Banana", 60.00);
		fruits.put("Papaya", 78.50);
		fruits.put("Mango", 120.25);
		fruits.put("Pine Apple", 100.75);
		//Normal without lambda
		System.out.println(fruits);
		
		//or
		for(Map.Entry<String,Double> entry:fruits.entrySet() ) {
			System.out.println(entry.getKey()+"="+entry.getValue());
		}
		System.out.println();
		//printing with Lambda
		fruits.forEach((k,v) -> System.out.print("\n"+k+"="+v));

	}

}
