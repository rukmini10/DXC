package lambda;

import java.util.ArrayList;
import java.util.List;

public class RetriveDataFromCollectionUsingLabda {

	public static void main(String[] args) {
		List<String> studentLeads=new ArrayList<String>();
		studentLeads.add("Isvariyashree");
		studentLeads.add("Rukmini");
		studentLeads.add("Srinika");
		studentLeads.add("Keerthi");
		studentLeads.add("Nikhila");
		studentLeads.add("Kakumani");
//		for(int i=0;i<studentLeads.size();i++) {
//			System.out.println(studentLeads.get(i));
//		}
		
		studentLeads.forEach(
				(names) -> System.out.println(names)
				);

	}

}
