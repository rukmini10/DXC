package lambda;
public class Planner {}
/*
 * Lambda expression consists following components:
 * 1. Argument list/parameter list: It can be blank or having some parameters
 * 2. Arrow token( ->): It is used to link parameter list with expression body
 * 3. Lambda Body: It contains statement for lambda.
 * 
 * 1. if there is no parameter with lambda
 * () -> {....}
 * 
 * 2. if there is one parameter with lambda
 * (para1) -> {.....}
 * 
 * 3. if there are morethan one parameter list with lambda
 * (para1,para2..paraN) -> {  ....}
 * 
 * 
 * 3. Neither getting value from user nor returning.
 * () -> System.out.println("welcome")
 * 
 * 4. Getting values from user and returning value too
 * (num) -> num*num
 * 
 * practice question:
 * productId,productName,productQuantity,productPrice
 * calcTotalPrice()
 * display all data with lambda
 */
