package com.wsgen.ws.calc.endpoint;

import javax.xml.ws.Endpoint;

import com.wsgen.ws.calc.Calculator;

public class CalcEndpointPublisher {

	public static void main(String[] args) {
		Endpoint.publish("http://localhost:8080/CalculatorService/Calculator", new Calculator());

	}

}
