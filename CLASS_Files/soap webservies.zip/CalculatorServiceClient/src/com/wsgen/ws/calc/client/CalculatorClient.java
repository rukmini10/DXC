package com.wsgen.ws.calc.client;

import com.wsgen.ws.calc.Calculator;
import com.wsgen.ws.calc.CalculatorService;

public class CalculatorClient {

	public static void main(String[] args) {
		int num1=Integer.parseInt(args[0]);
		int num2=Integer.parseInt(args[1]);
		CalculatorService calcService=new CalculatorService();
		Calculator calc=calcService.getCalculatorPort();
		System.out.println(num1+" + "+num2+" = "+calc.add(num1, num2));
		System.out.println(num1+" - "+num2+" = "+calc.sub(num1, num2));
		System.out.println(num1+" * "+num2+" = "+calc.mul(num1, num2));
		System.out.println(num1+" / "+num2+" = "+calc.div(num1, num2));
	}

}
