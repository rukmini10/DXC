@javax.xml.bind.annotation.XmlSchema(namespace = "http://calc.ws.wsgen.com/")
package com.wsgen.ws.calc;
