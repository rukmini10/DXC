@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.dxc.com/")
package com.dxc.ws;
