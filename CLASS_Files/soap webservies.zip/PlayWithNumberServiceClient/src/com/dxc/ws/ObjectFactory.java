
package com.dxc.ws;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.dxc.ws package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _NumberType_QNAME = new QName("http://ws.dxc.com/", "numberType");
    private final static QName _NumberSumResponse_QNAME = new QName("http://ws.dxc.com/", "numberSumResponse");
    private final static QName _NumberCube_QNAME = new QName("http://ws.dxc.com/", "numberCube");
    private final static QName _NumberSum_QNAME = new QName("http://ws.dxc.com/", "numberSum");
    private final static QName _NumberCubeResponse_QNAME = new QName("http://ws.dxc.com/", "numberCubeResponse");
    private final static QName _NumberTypeResponse_QNAME = new QName("http://ws.dxc.com/", "numberTypeResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.dxc.ws
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link NumberSumResponse }
     * 
     */
    public NumberSumResponse createNumberSumResponse() {
        return new NumberSumResponse();
    }

    /**
     * Create an instance of {@link NumberType }
     * 
     */
    public NumberType createNumberType() {
        return new NumberType();
    }

    /**
     * Create an instance of {@link NumberSum }
     * 
     */
    public NumberSum createNumberSum() {
        return new NumberSum();
    }

    /**
     * Create an instance of {@link NumberCube }
     * 
     */
    public NumberCube createNumberCube() {
        return new NumberCube();
    }

    /**
     * Create an instance of {@link NumberCubeResponse }
     * 
     */
    public NumberCubeResponse createNumberCubeResponse() {
        return new NumberCubeResponse();
    }

    /**
     * Create an instance of {@link NumberTypeResponse }
     * 
     */
    public NumberTypeResponse createNumberTypeResponse() {
        return new NumberTypeResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NumberType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.dxc.com/", name = "numberType")
    public JAXBElement<NumberType> createNumberType(NumberType value) {
        return new JAXBElement<NumberType>(_NumberType_QNAME, NumberType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NumberSumResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.dxc.com/", name = "numberSumResponse")
    public JAXBElement<NumberSumResponse> createNumberSumResponse(NumberSumResponse value) {
        return new JAXBElement<NumberSumResponse>(_NumberSumResponse_QNAME, NumberSumResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NumberCube }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.dxc.com/", name = "numberCube")
    public JAXBElement<NumberCube> createNumberCube(NumberCube value) {
        return new JAXBElement<NumberCube>(_NumberCube_QNAME, NumberCube.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NumberSum }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.dxc.com/", name = "numberSum")
    public JAXBElement<NumberSum> createNumberSum(NumberSum value) {
        return new JAXBElement<NumberSum>(_NumberSum_QNAME, NumberSum.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NumberCubeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.dxc.com/", name = "numberCubeResponse")
    public JAXBElement<NumberCubeResponse> createNumberCubeResponse(NumberCubeResponse value) {
        return new JAXBElement<NumberCubeResponse>(_NumberCubeResponse_QNAME, NumberCubeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NumberTypeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.dxc.com/", name = "numberTypeResponse")
    public JAXBElement<NumberTypeResponse> createNumberTypeResponse(NumberTypeResponse value) {
        return new JAXBElement<NumberTypeResponse>(_NumberTypeResponse_QNAME, NumberTypeResponse.class, null, value);
    }

}
