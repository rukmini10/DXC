package threadpool;

import java.util.Date;
import java.text.*;
//Creating task
public class Task implements Runnable{
	private String name;
	public Task(String name) {
		this.name=name;
	}

	@Override
	public void run() {
		try {
			for(int i=0;i<5;i++) {
				if(i==0) {
					Date today=new Date();
					SimpleDateFormat ft=new SimpleDateFormat("hh:mm:ss");
					System.out.print("\nStart time for"+" task name"+name
							+"="+ft.format(today));
				}else {
					Date today=new Date();
					SimpleDateFormat ft=new SimpleDateFormat("hh:mm:ss");
					System.out.print("\nStart time for"+" task name"+name
							+"="+ft.format(today));
				}
				Thread.sleep(1000);			}
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		System.out.print("\n"+name+"Completed..");
	}
	
}


/*
 * create a task
 * create Executor Pool with help of Executors
 * Pass tasks to Executor Pool
 * Shutdown the Executor Pool
 */


