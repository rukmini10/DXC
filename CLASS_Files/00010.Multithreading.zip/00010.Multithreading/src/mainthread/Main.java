package mainthread;

public class Main {

	public static void main(String[] args) {
		Thread t=Thread.currentThread();
		System.out.print("\nCurrent thread:"+t.getName());
		t.setName("Java");
		System.out.print("\nafter renaming thread:"+t.getName());
		System.out.print("\nMain Thread priority:"+t.getPriority());
		t.setPriority(10);
		System.out.print("\nMain Thread new priority:"+t.getPriority());
		for(int i=0;i<5;i++) {
			System.out.print("\nMain Thread");
		}
		//creating child thread object
		Thread ct=new Thread() {
			public void run() {
				for(int i=0;i<5;i++) {
					System.out.print("\nChild Thread");
				}
			}
		};
		System.out.print("\nChild Thread priority:"+ct.getPriority());
		ct.start();
	}

}
