package extendingthread;

class ThreadDemo1 extends Thread{
	public void run() {
		System.out.print("\n got processor time..");
		for(int i=1;i<30;i++) {
			System.out.print("\nThread name:"+this.getName()+" Thread Priority:"+this.getPriority());
			try {
				this.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.print("\n thread:"+this.getName()+" is out...");
	}
}

class ThreadDemo2 extends Thread{
	public void run() {
		System.out.print("\n got processor time..");
		for(int i=1;i<30;i++) {
			System.out.print("\nThread name:"+this.getName()+" Thread Priority:"+this.getPriority());
			if(i==20) {
				System.out.print("\nExisting priority is:"+this.getPriority());
				this.setPriority(MAX_PRIORITY);
			}
		}
		System.out.print("\n thread:"+this.getName()+" is out...");
	}
}
public class ThreadDemo{
	public static void main(String args[]) {
		System.out.print("\n Mother thread started...");
		ThreadDemo1 demo1=new ThreadDemo1();
		System.out.print("\n Demo1 thread started...");
		demo1.start();
		ThreadDemo2 demo2=new ThreadDemo2();
		System.out.print("\n Demo2 thread started...");
		demo2.start();
		System.out.print("\n Mother thread ended...");
		demo2.setPriority(8);
	}
	
}
