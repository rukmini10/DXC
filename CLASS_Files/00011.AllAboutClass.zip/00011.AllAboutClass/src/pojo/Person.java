package pojo;
import java.io.Serializable;
import java.util.Objects;
public class Person implements Serializable{
	private static final long serialVersionUID = 1L;
	private static int id=1000;
	private int personId;
	private String name;
	private String contactNumber;
	public static int getId() {
		return id;
	}
	
	public int getPersonId() {
		return personId;
	}
	public void setPersonId(int personId) {
		this.personId = personId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Person(String name, String contactNumber) {
		this.name = name;
		this.contactNumber = contactNumber;
		this.personId=id++;
	}

	
	@Override
	public int hashCode() {
		return Objects.hash(contactNumber, name, personId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		return Objects.equals(contactNumber, other.contactNumber) && Objects.equals(name, other.name)
				&& personId == other.personId;
	}

	@Override
	public String toString() {
		return "\n" + personId + ", " + name + ", " + contactNumber;
	}
}
