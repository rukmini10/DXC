package pojo;

import java.util.ArrayList;
import java.util.List;

public class PersonService {

	public static void main(String[] args) {
		List<Person> list=new ArrayList<Person>();
		list.add(new Person("Prasanna","1223344556"));
		list.add(new Person("Keerthi","4455612233"));
		list.add(new Person("Rukmini","3344512256"));
		list.add(new Person("Radhika","1455622334"));
		list.add(new Person("Harish","4556122334"));
		for(Person p:list) {
			System.out.print(p);
		}
	}

}
