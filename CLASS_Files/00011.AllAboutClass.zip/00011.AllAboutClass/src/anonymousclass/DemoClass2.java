package anonymousclass;
interface Display{
	void displayData();
}

public class DemoClass2 {
	static Display display=new Display() {
		public void displayData() {
		System.out.print("\n Hi all I am overrided this method using anonymus class");
		}
	};
	
	public static void main(String[] args) {
		display.displayData();
	

	}

}
