package anonymousclass;
public class DemoClass {
	void display() {
		System.out.print("Hi, I am from DemoClass");
	}
	public static void main(String args[]) {
		DemoClass demo=new DemoClass() {
			void display() {
				System.out.print("Hi, I am not in DemoClass");
			}
		};
		demo.display();
	}
}
