package anonymousclass;
class Demo{
	public void sayGreetings() {
			System.out.print("Greeting all, Welcome to java world.");
	}
}
public class DemoClass3 {	
	public static void main(String[] args) {
//		Demo demo=new Demo();
//		demo.sayGreetings();
		Demo demo=new Demo() {
			public void sayHi() {
				System.out.print("\nHi all, Welcome to java world.");
			}
			public void sayGreetings() {
				System.out.print("Greeting all, Welcome to Spring world.");
				sayHi();
		}
			
		};
		demo.sayGreetings();
		
	}

}
