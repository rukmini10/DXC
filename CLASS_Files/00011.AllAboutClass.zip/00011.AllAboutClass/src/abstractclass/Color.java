package abstractclass;

public abstract class Color {
	protected String colorName;
	public  void setColor(String colorName) {
		this.colorName=colorName;
	}
	public abstract void showColor();
		
	
}
