package abstractclass;

public class FillColor extends Color{
	@Override
	public void showColor() {
		System.out.print("\n"+"Color is :"+colorName);
		
	}
	public static void main(String[] args) {
		FillColor color=new FillColor();
		color.setColor("Dark Red");
		color.showColor();

	}

	

	
}
