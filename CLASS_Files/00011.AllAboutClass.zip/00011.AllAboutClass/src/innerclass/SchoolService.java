package innerclass;
public class SchoolService {
	public static void main(String[] args) {
		School school=new School();
		school.ShowStudent();
	}
}
