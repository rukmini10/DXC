package innerclass;

public class School {
	private String schoolName="DXC School";
	class Student{
		private int rollNumber;
		private String name;
		public int getRollNumber() {
			return rollNumber;
		}
		
		public String getName() {
			return name;
		}
		
		public Student(int rollNumber, String name) {
			super();
			this.rollNumber = rollNumber;
			this.name = name;
		}

		@Override
		public String toString() {
			return "\nStudent =>" + rollNumber + ", " + name+" , "+schoolName;
		}
	}
	private School.Student student=new School.Student(12,"Sanna");

	
	public void ShowStudent() {
		System.out.print(student);
	}
	
}
