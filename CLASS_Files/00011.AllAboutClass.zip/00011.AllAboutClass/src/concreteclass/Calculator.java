package concreteclass;
public class Calculator {
	public String compareNumbers(int num1,int num2) {
		String res=null;
		if(num1>num2) {
			res=num1+" is bigger than "+num2;
		}else if(num1<num2) {
			res=num1+" is smaller than "+num2;
		}else {
			res=num1+" and "+num2+" both are equal";
		}
		return res;
	}
	public static void main(String[] args) {
		Calculator calc=new Calculator();
		System.out.print("\n"+calc.compareNumbers(12, 45));
		System.out.print("\n"+calc.compareNumbers(34, 12));
		System.out.print("\n"+calc.compareNumbers(45, 45));
	}

}
