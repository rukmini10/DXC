package finalclass;

final public class DxcProfile {
	private String companyProfile;
	private int numberOfHead;
	private String companyType;
	public String getCompanyProfile() {
		return companyProfile;
	}
	public int getNumberOfHead() {
		return numberOfHead;
	}
	public String getCompanyType() {
		return companyType;
	}
	public DxcProfile(String companyProfile, int numberOfHead, String companyType) {
		super();
		this.companyProfile = companyProfile;
		this.numberOfHead = numberOfHead;
		this.companyType = companyType;
	}
	@Override
	public String toString() {
		return "DxcProfile =>" + companyProfile + ", " + numberOfHead + ", "+ companyType;
	}
}
