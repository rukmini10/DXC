package finalclass;

public class DxcProfileTest{

	public static void main(String[] args) {
		DxcProfile dxc=new DxcProfile("Big software company",100,"software");
		System.out.print(dxc);
	}

}
