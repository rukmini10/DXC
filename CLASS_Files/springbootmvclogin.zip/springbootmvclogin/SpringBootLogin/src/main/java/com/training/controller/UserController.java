package com.training.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.training.model.User;
import com.training.model.UserRepository;

@Controller
public class UserController {

	@Autowired
	private UserRepository userRepository;
	String message=null;
	
	@RequestMapping(value="/", method=RequestMethod.GET)
	public ModelAndView callingLogin() {
		return new ModelAndView("login");
	}
	
	@RequestMapping(value="registration", method=RequestMethod.GET)
	public ModelAndView callingRegistration() {
		return new ModelAndView("registration");
	}
	
	@RequestMapping(value="/addUser",method=RequestMethod.POST)
	public String addNewUser(@RequestParam String userFirstName,@RequestParam String userLastName,
			@RequestParam String userEmailId,@RequestParam String userRole,@RequestParam String userPassword) {
		User user=new User();
		user.setUserFirstName(userFirstName);
		user.setUserLastName(userLastName);
		user.setUserEmailId(userEmailId);
		user.setUserRole(userRole);
		user.setUserPassword(userPassword);
		userRepository.save(user);
		System.out.print("\nUser data has been saved..");
		return "login";
		}
	@RequestMapping("/delUser")
	public @ResponseBody String delUser(@RequestParam Integer userId) {
		userRepository.deleteById(userId);
		return "Record Deleted";
	}
	
	@RequestMapping("/checkUser")
	public @ResponseBody String checkUser(@RequestParam Integer userId) {
		String message=null;
		boolean present=false;
		present=userRepository.existsById(userId);
		if(present) {
		message="User is existing by id:"+userId;	
		}else {
			message="User is not existing by id:"+userId;
		}
		return message;
	}
	
	@RequestMapping("/countUsers")
	public @ResponseBody String countUser() {
		long users=userRepository.count();
		return String.format("Number of records :%d+ found",users);
	}
	
	@RequestMapping(value="/validUser",method=RequestMethod.POST)
	public String validUser(@RequestParam Integer userId,@RequestParam String userPassword,
			@RequestParam String userRole,Model model) {
		Optional<User>user=null;
		String page=null;
		String message=null;
		user=userRepository.findById(userId);
	
		if(user!=null && user.get().getUserRole().equals(userRole) 
				&& user.get().getUserPassword().equals(userPassword)) {
			page="home_"+userRole;
			message="Hi "+userRole+" you are welcome";
		}else {
			page="login";
			message="Please try again if your login exist othewise pleae register first..";
		}
		model.addAttribute("username", user.get().getUserFirstName());
		model.addAttribute("message", message);
		return page;
	}
	
	@RequestMapping("/getUser")
	public @ResponseBody Optional<User> getUser(@RequestParam Integer userId){
		return userRepository.findById(userId);
	}
	@RequestMapping("/allUsers")
	public @ResponseBody String allUsers() {
		String records="";
		List <User>list=(List<User>) userRepository.findAll();
		for(User user:list) {
			records+=user+"<br>";
		}
		return records;
	}
}





