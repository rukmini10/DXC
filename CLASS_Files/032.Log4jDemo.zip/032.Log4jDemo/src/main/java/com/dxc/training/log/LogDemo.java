package com.dxc.training.log;


import java.io.FileNotFoundException;
import java.io.IOException;


import org.apache.log4j.Logger;

public class LogDemo {
private void callingMe(String msg) {
	if(logger.isDebugEnabled()) {
		logger.debug("this is a debug "+msg);
	}
	if(logger.isInfoEnabled()) {
		logger.debug("this is a info "+msg);
	}
	
	logger.warn("this if warn"+msg);
	logger.error("this if warn"+msg);
	logger.fatal("this if fatel"+msg);
}
	final static Logger logger=Logger.getLogger(LogDemo.class);
	public static void main(String[] args) throws FileNotFoundException, IOException {

		LogDemo logDemo=new LogDemo();
		logDemo.callingMe("Hello applicant");
	}

}
