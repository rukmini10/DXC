package com.dxc.training;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dxc.training.bean.Student;
import com.dxc.training.dao.StudentDAOImpl;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
        StudentDAOImpl stDAO=(StudentDAOImpl)context.getBean("studentDAOImpl");
        
        System.out.print("\n------------Adding new Records----------------------");
        stDAO.createStudent("Manoj", "Science", 89.90f);
        stDAO.createStudent("Mitta", "Arts", 78.00f);
        stDAO.createStudent("Aditee", "Science", 88.75f);
        stDAO.createStudent("Ram", "ComputerScience", 99.30f);
        
        System.out.print("\n------------Show All Records----------------------");
        List <Student> students=stDAO.listStudents();
        for(Student st:students) {
        System.out.print("\n"+st);	
        }
        
        System.out.print("\n------------Modifying a record----------------------");
        stDAO.updateStudent(2, "Science", 88.00f);
        
        System.out.print("\n------------Show record by rollno----------------------");
        Student student=stDAO.getStudentById(2);
        System.out.print("\n"+student);	
        
        System.out.print("\n------------Show record by rollno----------------------");
        stDAO.deleteStudentById(2);
        
        System.out.print("\n------------Show All Records----------------------");
        students=stDAO.listStudents();
        for(Student st:students) {
        System.out.print("\n"+st);	
        }
        
    }
}
