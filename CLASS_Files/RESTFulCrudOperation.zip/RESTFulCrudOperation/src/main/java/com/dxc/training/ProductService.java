package com.dxc.training;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/service")
public class ProductService {
	//uri: http://localhost:8082/RESTFulCrudOperation/rest/service/products
	private ProductDAO dao=ProductDAO.getDao();
	
	@GET
	@Path("/products")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> products(){
		return dao.getProducts();
	}
	
	@GET
	@Path("/products/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getProduct(@PathParam("id") int id) {
		Product product=dao.getProductById(id);
		System.out.print("\n"+product);
		if(product!=null) {
			return Response.ok(product,MediaType.APPLICATION_JSON).build();
		}else {
			return Response.status(Response.Status.NOT_FOUND).build();
		}
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	//@Path("/products")
	public Response addProduct(Product product) throws URISyntaxException {
		int newProductId=dao.addProduct(product);
		URI uri=new URI("/products/"+newProductId);
		return Response.created(uri).build();
	}
	
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/products/{id}")
	public Response updateProduct(@PathParam("id") int id,Product product) {
		product.setProductId(id);
		if(dao.updateProduct(product)) {
			return Response.ok().build();
		}else {
			return Response.notModified().build();
		}
	}
	
	@DELETE
	@Path("/products/{id}")
	public Response deleteProduct(@PathParam("id") int id) {
		if(dao.deleteProduct(id)) {
			return Response.ok().build();
		}else {
			return Response.notModified().build();
		}
	}
	
	
}
