package com.dxc.training;

import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
	private static ProductDAO dao;
	private static List<Product> products=new ArrayList<>();
	
	static {
		products.add(new Product(1,"Mouse",2,450.50f));
		products.add(new Product(2,"Keyboard",4,3450.50f));
		products.add(new Product(3,"CPU",1,24500.40f));
		products.add(new Product(4,"Monitor",2,6450.25f));
	}
	
	public ProductDAO() {
	}

	public static ProductDAO getDao() {
		if(dao==null) {
			dao=new ProductDAO();
		}
		return dao;
	}

	public List<Product> getProducts(){
		return products;
	}
	
	public int addProduct(Product product) {
		int newId=products.size()+1;
		product.setProductId(newId);
		products.add(product);
		return newId;
	}
	
	public Product getProductById(int id) {
		
		for(Product product:products) {
			if(product.getProductId()==id) {
				return product;
			}
		}
		return null;
	}
	
	public boolean updateProduct(Product product) {
		int index=-1;
		for(Product prod:products) {
			++index;
			if(prod.getProductId()==product.getProductId()) {
				products.set(index, product);
				return true;
			}
		}
		
			return false;	
	}
	
	public boolean deleteProduct(int id) {
		for(Product product:products) {
			if(product.getProductId()==id) {
				products.remove(product);
				return true;
			}
		}
		return false;
	}
}
