package streamwithfilter;

import java.util.Arrays;
import java.util.List;

class Employee{
	private String empName;
	private Integer empAge;
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Integer getEmpAge() {
		return empAge;
	}
	public void setEmpAge(Integer empAge) {
		this.empAge = empAge;
	}
	public Employee(String empName, Integer empAge) {
		super();
		this.empName = empName;
		this.empAge = empAge;
	}
	@Override
	public String toString() {
		return "\n" + empName + ", " + empAge;
	}
	
}
public class StreamWithFilter {

	public static void main(String[] args) {
		List<Employee>employees=Arrays.asList(new Employee("Pranav",23),
				new Employee("Pradeep",26),
				new Employee("Surender",30),
				new Employee("Dileep",33),
				new Employee("Manisha",13),
				new Employee("Parwati",20)
				);
		//Show first 3 records of employees
		for(int i=0;i<employees.size();i++) {
			if(i<3) {
				System.out.println(employees.get(i));
			}
		}
		
		//or
		List<Employee> firstThreeRecords=employees.stream().limit(3).toList();
		firstThreeRecords.stream().forEach(System.out::println);
		
		
		//Show first 3 records of employees
		for(int i=employees.size()-1,count=0;i>=0;i--) {
			if(count<3) {
				System.out.println(employees.get(i));
				count++;
			}
		}
		System.out.println("for negative limit:");
		List<Employee> firstThreeRecords2=employees.stream().limit(-3).toList();
		firstThreeRecords2.stream().forEach(System.out::println);

	}

}
