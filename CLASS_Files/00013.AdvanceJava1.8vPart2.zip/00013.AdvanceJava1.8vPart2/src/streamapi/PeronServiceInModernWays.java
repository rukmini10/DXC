package streamapi;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.*;
public class PeronServiceInModernWays {

	public static void main(String[] args) {
		//Adding some new Person objects in list
		List<Person> persons=Arrays.asList(new Person("Fatima","Manglore","1223344556"),
				new Person("Rajiya","Delhi","4455612233"),
				new Person("Jafira","Maharastra","1344556223"),
				new Person("Asfia","Delhi","5561223344"),
				new Person("Noori","Manglore","3344122556"));
		List<String> list=persons.stream().map(Person::getFirstName).collect(Collectors.toList());
		System.out.println(list);

		Set<String> set=persons.stream()
				.map(Person::getFirstName)
				.collect(Collectors.toCollection(TreeSet::new));
		System.out.println(set);
	}

}
