package streamapi;

import java.util.Arrays;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/*
 * class Employee:empId,empName,empDepartment,salary,empAppraisalGrade
 * 0.Create few Employee Objects 
 * 1.Calculate totalSalary of all employees
 * 2.Grouping employees department wise
 * 3.Calculate sum of salaries department wise
 * 4.Partitoning Employees into AppraisalGrade wise
 */
//class Employee:empId,empName,empDepartment,salary,empAppraisalGrade
class Employee{
	private int empId;
	private String empName;
	private String empDepartment;
	private int salary;
	private String empAppraisalGrade;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpDepartment() {
		return empDepartment;
	}
	public void setEmpDepartment(String empDepartment) {
		this.empDepartment = empDepartment;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getEmpAppraisalGrade() {
		return empAppraisalGrade;
	}
	public void setEmpAppraisalGrade(String empAppraisalGrade) {
		this.empAppraisalGrade = empAppraisalGrade;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int empId, String empName, String empDepartment, int salary, String empAppraisalGrade) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empDepartment = empDepartment;
		this.salary = salary;
		this.empAppraisalGrade = empAppraisalGrade;
	}
	@Override
	public String toString() {
		return "\n" + empId + ", " + empName + ", " + empDepartment + ", "
				+ salary + ", " + empAppraisalGrade;
	}
	
}
public class EmployeeService {

	public static void main(String[] args) {
		//0.Create few Employee Objects 
		List<Employee> employees=Arrays.asList(
				new Employee(101,"Harish","Production",67500,"Pass"),
				new Employee(102,"Chaitanya","HR",56700,"Pass"),
				new Employee(103,"Kakumani","Development",56700,"Pass"),
				new Employee(104,"Rukmini","Development",56700,"Fail"),
				new Employee(105,"Keerthi","HR",56700,"Pass"),
				new Employee(106,"Iswariyasri","Development",70560,"Pass"),
				new Employee(107,"Radhika","Production",56070,"Pass"),
				new Employee(108,"Fatima","Development",5670056,"Fail")
				);
		//1.Calculate totalSalary of all employees	
		int totalSalary=employees.stream()
				.collect(Collectors.summingInt(Employee::getSalary));
		System.out.println("\n Total Salary:"+totalSalary);
		
		//total Salary:DoubleSummaryStatistics{count=8, sum=6090986.000000, min=56070.000000, average=761373.250000, max=5670056.000000}
		DoubleSummaryStatistics totalSalary1=employees.stream()
				.collect(Collectors.summarizingDouble(Employee::getSalary));
		System.out.println("\n Total Salary:"+totalSalary1);
		
		//2.Grouping employees department wise
		Map<String,List<Employee>> emplyeeDepartmentWise=employees.stream()
				.collect(Collectors.groupingBy(Employee::getEmpDepartment));
		System.out.println(emplyeeDepartmentWise);
		
		//3.Calculate sum of salaries department wise
		Map<String,Integer> departmentWiseSalary=employees.stream()
				.collect(Collectors.groupingBy(Employee::getEmpDepartment,
						Collectors.summingInt(Employee::getSalary)));
		System.out.println(departmentWiseSalary);
		
		//4.Partitoning Employees into AppraisalGrade wise
		Map<Boolean,List<Employee>> appraisalGrade=employees.stream()
				.collect(Collectors.partitioningBy(emp -> emp.getEmpAppraisalGrade()
						.equals("Pass")));
		System.out.println(appraisalGrade);
	}

}
