package streamapi;
public class Planner {}
/*
 * Write java code to make a list of object and display their name only.
 * Person: firstName,city and contactNumber
 * we have 10 persons in ArrayList, show all firstName only.
 * 
 * 
 * 
 * Employee:
 * empId,empName,empDepartment,salary,empAppraisalGrade
 * 1.Calculate totalSalary of all employees
 * 2.Make group of employees department wise
 * 3.Calculate sum of salaries department wise
 * 4.Partitoning Employees into AppraisalGrade wise
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
