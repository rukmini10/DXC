package streamapi;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.*;
import java.util.TreeSet;

public class CommonUserOfStreamApi {

	public static void main(String[] args) {
		List<String> countries=Arrays.asList("Inida","ShriLanka","","Bhutan","","Nepal","BangalaDesh");
		
		//filtering blank countries
		List<String> countries2=countries.stream()
				.filter(country -> !countries.isEmpty()).collect(Collectors.toList());
		System.out.println(countries2);
		
		
		//Converting give list into set
		Set<String> set=countries.stream()
				.collect(Collectors.toCollection(TreeSet::new));
		System.out.println(set);
		
		//Converting list of string into a single string
		String singleString=countries.stream()
				.map(Object::toString)
				.collect(Collectors.joining(", "));
		System.out.println(singleString);
		
	}
}
