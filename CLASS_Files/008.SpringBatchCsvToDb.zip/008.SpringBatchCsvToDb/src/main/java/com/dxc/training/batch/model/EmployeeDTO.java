package com.dxc.training.batch.model;

import java.io.Serializable;

public class EmployeeDTO implements Serializable{
	private static final long serialVersionUID = 1L;
	private String empid;
	private String firstname;
	private String companyname;
	private String city;
	private String country;
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public EmployeeDTO() {
	}
	public EmployeeDTO(String empid, String firstname, String companyname, String city, String country) {
		this.empid = empid;
		this.firstname = firstname;
		this.companyname = companyname;
		this.city = city;
		this.country = country;
	}
	@Override
	public String toString() {
		return "\n" + empid + ", " + firstname + ", " + companyname + ", "
				+ city + ", " + country;
	}
}