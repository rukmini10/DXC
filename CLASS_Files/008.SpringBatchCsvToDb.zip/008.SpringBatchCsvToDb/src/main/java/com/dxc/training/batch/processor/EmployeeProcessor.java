package com.dxc.training.batch.processor;
import org.springframework.batch.item.ItemProcessor;
import com.dxc.training.batch.model.Employee;
import com.dxc.training.batch.model.EmployeeDTO;

public class EmployeeProcessor implements ItemProcessor<Employee,EmployeeDTO>{
	@Override
	public EmployeeDTO process(Employee employee) throws Exception {
		System.out.print("\nTransforming Employee to EmployeeDTO..");
		EmployeeDTO employeeDTO=new EmployeeDTO(employee.getEmpid(),employee.getFirstname(),
				employee.getCompanyname(),employee.getCity(),employee.getCountry());
		return employeeDTO;
	}

}
