create table employee(
empid varchar(10),
first_name varchar(15),
company_name varchar(25),
city varchar(15),
country varchar(20)
);