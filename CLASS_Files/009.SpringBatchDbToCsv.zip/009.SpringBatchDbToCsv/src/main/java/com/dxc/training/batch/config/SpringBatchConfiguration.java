package com.dxc.training.batch.config;

import java.io.IOException;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import com.dxc.training.batch.mapper.EmployeeRowMapper;
import com.dxc.training.batch.model.Employee;
import com.dxc.training.batch.processor.EmployeeItemProcessor;


@Configuration
@EnableBatchProcessing
public class SpringBatchConfiguration {
	@Autowired
	public JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	public StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	public DataSource dataSource;
	
	@Bean
	public JdbcCursorItemReader<Employee>reader(){
		JdbcCursorItemReader<Employee> reader=new JdbcCursorItemReader<Employee>();
		reader.setDataSource(dataSource);
		reader.setSql("select empid, first_name, company_name, city, country from employee");
		reader.setRowMapper(new EmployeeRowMapper());
		return reader;
	}
	
	@Bean
	public EmployeeItemProcessor processor() {
		return new EmployeeItemProcessor();
	}
	
	@Bean
	public FlatFileItemWriter<Employee> writer() throws IOException{
		FlatFileItemWriter<Employee> writer=new FlatFileItemWriter<Employee>();
		System.out.print("\n"+new ClassPathResource("").getFile().getAbsolutePath());
		writer.setResource(new ClassPathResource("employee.csv"));
		writer.setLineAggregator(new DelimitedLineAggregator<Employee>() {{
			setDelimiter(",");
			setFieldExtractor(new BeanWrapperFieldExtractor<Employee>() {{
				setNames(new String [] {"empid","firstname","companyname","city","country"});
			}});
		}});
		return writer;
	}
	
	@Bean
	public Step step1() throws IOException {
		return stepBuilderFactory.get("step1")
				.<Employee,Employee> chunk(5)
				.reader(reader())
				.processor(processor())
				.writer(writer())
				.build();
	} 
	
	@Bean
	public Job exportUserJob() throws IOException {
		return jobBuilderFactory.get("exportUserJob")
				.incrementer(new RunIdIncrementer())
				.flow(step1())
				.end()
				.build();
	}
	
}
