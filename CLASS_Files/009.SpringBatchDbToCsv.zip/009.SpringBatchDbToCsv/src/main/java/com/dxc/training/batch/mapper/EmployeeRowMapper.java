package com.dxc.training.batch.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dxc.training.batch.model.Employee;

public class EmployeeRowMapper implements RowMapper<Employee>{

	@Override
	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		Employee employee=new Employee();
		employee.setEmpid(rs.getString("empid"));
		employee.setFirstname(rs.getString("first_name"));
		employee.setCompanyname(rs.getString("company_name"));
		employee.setCity(rs.getString("city"));
		employee.setCountry(rs.getString("country"));
		return employee;
	}

}
