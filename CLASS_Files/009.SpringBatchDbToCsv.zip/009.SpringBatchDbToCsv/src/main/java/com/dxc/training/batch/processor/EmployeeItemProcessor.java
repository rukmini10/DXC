package com.dxc.training.batch.processor;
import org.springframework.batch.item.ItemProcessor;
import com.dxc.training.batch.model.Employee;
public class EmployeeItemProcessor implements ItemProcessor<Employee, Employee>{
	@Override
	public Employee process(Employee employee) throws Exception {
		return employee;
	}
}
