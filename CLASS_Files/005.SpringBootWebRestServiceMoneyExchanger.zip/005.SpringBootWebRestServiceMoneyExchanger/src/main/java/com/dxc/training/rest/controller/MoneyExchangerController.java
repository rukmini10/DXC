package com.dxc.training.rest.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.dxc.training.rest.service.MoneyExanger;

@RestController
public class MoneyExchangerController {
	@Autowired
	private MoneyExanger moneyExchanger;
	
	@RequestMapping(value="/moneyExchanger",method=RequestMethod.GET)
	public String callHome() {
		return "welcome to MoneyExchanger";
	}
	
	@RequestMapping(value="/moneyExchanger/{money}",method=RequestMethod.GET)
	public String convertingRuppyToDoller(@PathVariable double money) {
		return moneyExchanger.ruppyToDoller(money);
	}
	@RequestMapping(value="/moneyExchanger/{money}",method=RequestMethod.POST)
	public String convertingDollerToRuppy(@PathVariable double money) {
		return moneyExchanger.dollerToRuppy(money);
	}
	
}
