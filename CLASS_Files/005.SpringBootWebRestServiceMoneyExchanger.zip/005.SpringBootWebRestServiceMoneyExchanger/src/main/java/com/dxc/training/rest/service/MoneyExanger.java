package com.dxc.training.rest.service;

import org.springframework.stereotype.Service;

@Service
public class MoneyExanger {
	private double ruppy;
	private double doller;
	public double getRuppy() {
		return ruppy;
	}
	public void setRuppy(double ruppy) {
		this.ruppy = ruppy;
	}
	public double getDoller() {
		return doller;
	}
	public void setDoller(double doller) {
		this.doller = doller;
	}
	public MoneyExanger() {
		this.setDoller(0);
		this.setRuppy(0);
	}
	public String ruppyToDoller(double ruppy) {
		this.setRuppy(ruppy);
		this.setDoller(ruppy/76.44);
		return String.format("%s",this.getDoller());
	}
	public String dollerToRuppy(double doller) {
		this.setDoller(doller);
		this.setRuppy(doller*76.44);
		return String.format("%s",this.getRuppy());
	}
	@Override
	public String toString() {
		return "MoneyExanger => ruppy=" + ruppy + ", doller=" + doller;
	}
}
