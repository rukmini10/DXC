package com.dxc.training.bean;

public class Greetings {
	public void sayHello() {
		System.out.print("Hello Everyone, you are welcom in Spring Programming..");
	}
}
