package com.dxc.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dxc.training.bean.Greetings;

public class App 
{
    public static void main( String[] args )
    {
       ApplicationContext context=new ClassPathXmlApplicationContext("SpringBean.xml");
       Greetings greetings=(Greetings) context.getBean("hello");
       greetings.sayHello();
    }
}
