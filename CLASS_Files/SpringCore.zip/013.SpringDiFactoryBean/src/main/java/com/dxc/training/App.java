package com.dxc.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dxc.training.bean.Employee;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
    	Employee emp=(Employee)context.getBean("developer");
    	System.out.println(emp);
    	emp=(Employee)context.getBean("manager");
    	System.out.println(emp);
    	emp=(Employee)context.getBean("teamLead");
    	System.out.println(emp);
    	
    }
}
