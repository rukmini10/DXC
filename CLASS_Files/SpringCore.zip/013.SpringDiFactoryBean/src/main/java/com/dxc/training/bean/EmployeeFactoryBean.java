package com.dxc.training.bean;

import org.springframework.beans.factory.config.AbstractFactoryBean;

public class EmployeeFactoryBean extends AbstractFactoryBean<Object>{
	private String designation;
	
	public void setDesignation(String designation) {
		this.designation = designation;
	}

	@Override
	protected Object createInstance() throws Exception {
		Employee emp=new Employee();
		emp.setEmpId(111);
		emp.setEmpFirstName("Kakumani");
		emp.setEmpLastName("Pavan");
		emp.setEmpContactNumber("98154421");
		emp.setEmpDesignation(this.designation);
		emp.setEmpSalary(789800);
		return emp;
	}

	@Override
	public Class<Employee> getObjectType() {
		return Employee.class;
	}

}
