package com.dxc.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dxc.training.bean.Calculator;

public class App 
{
	public static void main( String[] args )
    {
    	ApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
    	Calculator calculator=(Calculator) context.getBean("calc1");
    	System.out.println("\nAddition:"+calculator.addNumbers());
    	System.out.println("\nSubtraction:"+calculator.subNumbers());
    	
    	calculator=(Calculator) context.getBean("calc2");
    	System.out.println("\nAddition:"+calculator.addNumbers());
    	System.out.println("\nSubtraction:"+calculator.subNumbers());
    }
	
	
}
