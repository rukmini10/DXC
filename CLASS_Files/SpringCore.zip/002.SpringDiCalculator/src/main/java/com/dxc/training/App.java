package com.dxc.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dxc.training.bean.Calculator;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
    	Calculator calculator=(Calculator) context.getBean("calc");
    	System.out.println("\nAddition:"+calculator.add(12,23));
    	System.out.println("\nSubtraction:"+calculator.sub(62,23));
    }
}
